import React, { useState } from 'react';
import styles from './ApprovalRulesPage.module.css';

const ApprovalRulesPage = () => {
  const [rules, setRules] = useState([
    {
      id: 1,
      name: 'High Amount Approval',
      description: 'Expenses over $500 require manager approval',
      amountThreshold: 500,
      currency: 'USD',
      approvers: ['Sarah Johnson', 'David Wilson'],
      categories: ['Travel', 'Office Supplies'],
      departments: ['Engineering', 'Sales'],
      isActive: true,
      createdAt: '2024-01-01'
    },
    {
      id: 2,
      name: 'Travel Expense Rule',
      description: 'All travel expenses require approval',
      amountThreshold: 0,
      currency: 'USD',
      approvers: ['Sarah Johnson'],
      categories: ['Travel'],
      departments: ['All'],
      isActive: true,
      createdAt: '2024-01-05'
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newRule, setNewRule] = useState({
    name: '',
    description: '',
    amountThreshold: '',
    currency: 'USD',
    approvers: [],
    categories: [],
    departments: [],
    isActive: true
  });

  const categories = [
    'Food & Dining', 'Transportation', 'Entertainment', 'Utilities',
    'Office Supplies', 'Travel', 'Healthcare', 'Education', 'Other'
  ];

  const departments = [
    'Engineering', 'Sales', 'Marketing', 'HR', 'Finance', 'Operations', 'All'
  ];

  const availableApprovers = [
    'Sarah Johnson', 'David Wilson', 'Mike Smith', 'Lisa Brown'
  ];

  const handleCreateRule = () => {
    const rule = {
      id: rules.length + 1,
      ...newRule,
      amountThreshold: parseFloat(newRule.amountThreshold) || 0,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setRules(prev => [...prev, rule]);
    setNewRule({
      name: '',
      description: '',
      amountThreshold: '',
      currency: 'USD',
      approvers: [],
      categories: [],
      departments: [],
      isActive: true
    });
    setShowCreateForm(false);
  };

  const handleDeleteRule = (ruleId) => {
    setRules(prev => prev.filter(rule => rule.id !== ruleId));
  };

  const handleToggleRule = (ruleId) => {
    setRules(prev => prev.map(rule => 
      rule.id === ruleId ? { ...rule, isActive: !rule.isActive } : rule
    ));
  };

  const handleApproverChange = (approver) => {
    setNewRule(prev => ({
      ...prev,
      approvers: prev.approvers.includes(approver)
        ? prev.approvers.filter(a => a !== approver)
        : [...prev.approvers, approver]
    }));
  };

  const handleCategoryChange = (category) => {
    setNewRule(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category]
    }));
  };

  const handleDepartmentChange = (department) => {
    setNewRule(prev => ({
      ...prev,
      departments: prev.departments.includes(department)
        ? prev.departments.filter(d => d !== department)
        : [...prev.departments, department]
    }));
  };

  return (
    <div className={styles.approvalRules}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>Approval Rules</h1>
          <p className={styles.pageSubtitle}>
            Configure automated approval workflows and rules
          </p>
        </div>
        <button 
          className={styles.createRuleButton}
          onClick={() => setShowCreateForm(true)}
        >
          Create Rule
        </button>
      </div>

      {/* Rules Stats */}
      <div className={styles.rulesStats}>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>📋</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{rules.length}</span>
            <span className={styles.statLabel}>Total Rules</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>✅</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              {rules.filter(r => r.isActive).length}
            </span>
            <span className={styles.statLabel}>Active Rules</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>👥</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              {new Set(rules.flatMap(r => r.approvers)).size}
            </span>
            <span className={styles.statLabel}>Unique Approvers</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>💰</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              ${Math.max(...rules.map(r => r.amountThreshold))}
            </span>
            <span className={styles.statLabel}>Highest Threshold</span>
          </div>
        </div>
      </div>

      {/* Rules List */}
      <div className={styles.rulesList}>
        <div className={styles.listHeader}>
          <h2 className={styles.listTitle}>Approval Rules</h2>
        </div>
        <div className={styles.rulesGrid}>
          {rules.map((rule) => (
            <div key={rule.id} className={styles.ruleCard}>
              <div className={styles.ruleHeader}>
                <div className={styles.ruleInfo}>
                  <h3 className={styles.ruleName}>{rule.name}</h3>
                  <p className={styles.ruleDescription}>{rule.description}</p>
                </div>
                <div className={styles.ruleStatus}>
                  <span className={`${styles.statusBadge} ${rule.isActive ? styles.active : styles.inactive}`}>
                    {rule.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
              
              <div className={styles.ruleDetails}>
                <div className={styles.detailItem}>
                  <span className={styles.detailLabel}>Amount Threshold:</span>
                  <span className={styles.detailValue}>
                    {rule.currency} {rule.amountThreshold}
                  </span>
                </div>
                
                <div className={styles.detailItem}>
                  <span className={styles.detailLabel}>Approvers:</span>
                  <div className={styles.approversList}>
                    {rule.approvers.map((approver, index) => (
                      <span key={index} className={styles.approverTag}>
                        {approver}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className={styles.detailItem}>
                  <span className={styles.detailLabel}>Categories:</span>
                  <div className={styles.categoriesList}>
                    {rule.categories.map((category, index) => (
                      <span key={index} className={styles.categoryTag}>
                        {category}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className={styles.detailItem}>
                  <span className={styles.detailLabel}>Departments:</span>
                  <div className={styles.departmentsList}>
                    {rule.departments.map((department, index) => (
                      <span key={index} className={styles.departmentTag}>
                        {department}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className={styles.ruleActions}>
                <button 
                  className={styles.toggleButton}
                  onClick={() => handleToggleRule(rule.id)}
                >
                  {rule.isActive ? 'Deactivate' : 'Activate'}
                </button>
                <button className={styles.editButton}>Edit</button>
                <button 
                  className={styles.deleteButton}
                  onClick={() => handleDeleteRule(rule.id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Rule Form Modal */}
      {showCreateForm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>Create Approval Rule</h2>
              <button 
                className={styles.closeButton}
                onClick={() => setShowCreateForm(false)}
              >
                ×
              </button>
            </div>
            
            <div className={styles.modalBody}>
              <div className={styles.formGrid}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Rule Name *</label>
                  <input
                    type="text"
                    className={styles.formInput}
                    placeholder="Enter rule name"
                    value={newRule.name}
                    onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Description *</label>
                  <textarea
                    className={styles.formTextarea}
                    placeholder="Describe the rule"
                    rows="3"
                    value={newRule.description}
                    onChange={(e) => setNewRule(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Amount Threshold</label>
                  <div className={styles.amountInput}>
                    <input
                      type="number"
                      className={styles.formInput}
                      placeholder="0"
                      value={newRule.amountThreshold}
                      onChange={(e) => setNewRule(prev => ({ ...prev, amountThreshold: e.target.value }))}
                    />
                    <select
                      className={styles.currencySelect}
                      value={newRule.currency}
                      onChange={(e) => setNewRule(prev => ({ ...prev, currency: e.target.value }))}
                    >
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                      <option value="GBP">GBP</option>
                    </select>
                  </div>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Approvers *</label>
                  <div className={styles.checkboxGroup}>
                    {availableApprovers.map(approver => (
                      <label key={approver} className={styles.checkboxLabel}>
                        <input
                          type="checkbox"
                          checked={newRule.approvers.includes(approver)}
                          onChange={() => handleApproverChange(approver)}
                        />
                        <span className={styles.checkboxText}>{approver}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Categories</label>
                  <div className={styles.checkboxGroup}>
                    {categories.map(category => (
                      <label key={category} className={styles.checkboxLabel}>
                        <input
                          type="checkbox"
                          checked={newRule.categories.includes(category)}
                          onChange={() => handleCategoryChange(category)}
                        />
                        <span className={styles.checkboxText}>{category}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Departments</label>
                  <div className={styles.checkboxGroup}>
                    {departments.map(department => (
                      <label key={department} className={styles.checkboxLabel}>
                        <input
                          type="checkbox"
                          checked={newRule.departments.includes(department)}
                          onChange={() => handleDepartmentChange(department)}
                        />
                        <span className={styles.checkboxText}>{department}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className={styles.modalActions}>
              <button 
                className={styles.cancelButton}
                onClick={() => setShowCreateForm(false)}
              >
                Cancel
              </button>
              <button 
                className={styles.createButton}
                onClick={handleCreateRule}
              >
                Create Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ApprovalRulesPage;
