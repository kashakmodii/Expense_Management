import React, { useState } from 'react';
import styles from './UserManagementPage.module.css';

const UserManagementPage = () => {
  const [users, setUsers] = useState([
    {
      id: 1,
      name: 'John Doe',
      email: 'john.doe@company.com',
      role: 'Employee',
      department: 'Engineering',
      status: 'active',
      lastLogin: '2024-01-15',
      expensesSubmitted: 15
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@company.com',
      role: 'Manager',
      department: 'Engineering',
      status: 'active',
      lastLogin: '2024-01-15',
      expensesSubmitted: 8
    },
    {
      id: 3,
      name: 'Mike Smith',
      email: 'mike.smith@company.com',
      role: 'Employee',
      department: 'Sales',
      status: 'active',
      lastLogin: '2024-01-14',
      expensesSubmitted: 22
    },
    {
      id: 4,
      name: 'Lisa Brown',
      email: 'lisa.brown@company.com',
      role: 'Admin',
      department: 'HR',
      status: 'active',
      lastLogin: '2024-01-15',
      expensesSubmitted: 5
    },
    {
      id: 5,
      name: 'David Wilson',
      email: 'david.wilson@company.com',
      role: 'Manager',
      department: 'Sales',
      status: 'inactive',
      lastLogin: '2024-01-10',
      expensesSubmitted: 12
    }
  ]);

  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    role: '',
    department: '',
    status: ''
  });

  const departments = ['Engineering', 'Sales', 'Marketing', 'HR', 'Finance', 'Operations'];
  const roles = ['Employee', 'Manager', 'Admin'];

  const getRoleColor = (role) => {
    const colors = {
      'Admin': styles.roleAdmin,
      'Manager': styles.roleManager,
      'Employee': styles.roleEmployee
    };
    return colors[role] || styles.roleDefault;
  };

  const getStatusColor = (status) => {
    return status === 'active' ? styles.statusActive : styles.statusInactive;
  };

  const handleDeleteUser = (userId) => {
    setUsers(prev => prev.filter(user => user.id !== userId));
  };

  const handleToggleStatus = (userId) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === 'active' ? 'inactive' : 'active' }
        : user
    ));
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                         user.email.toLowerCase().includes(filters.search.toLowerCase());
    const matchesRole = !filters.role || user.role === filters.role;
    const matchesDepartment = !filters.department || user.department === filters.department;
    const matchesStatus = !filters.status || user.status === filters.status;
    
    return matchesSearch && matchesRole && matchesDepartment && matchesStatus;
  });

  return (
    <div className={styles.userManagement}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>User Management</h1>
          <p className={styles.pageSubtitle}>
            Manage users, roles, and permissions
          </p>
        </div>
        <button 
          className={styles.addUserButton}
          onClick={() => setShowAddUserForm(true)}
        >
          Add User
        </button>
      </div>

      {/* User Stats */}
      <div className={styles.userStats}>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>👥</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{users.length}</span>
            <span className={styles.statLabel}>Total Users</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>✅</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              {users.filter(u => u.status === 'active').length}
            </span>
            <span className={styles.statLabel}>Active Users</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>👑</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              {users.filter(u => u.role === 'Manager' || u.role === 'Admin').length}
            </span>
            <span className={styles.statLabel}>Managers & Admins</span>
          </div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statIcon}>💰</div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>
              {users.reduce((sum, user) => sum + user.expensesSubmitted, 0)}
            </span>
            <span className={styles.statLabel}>Total Expenses</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className={styles.filtersSection}>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Search</label>
          <input
            type="text"
            placeholder="Search users..."
            className={styles.filterInput}
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
          />
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Role</label>
          <select
            className={styles.filterSelect}
            value={filters.role}
            onChange={(e) => setFilters(prev => ({ ...prev, role: e.target.value }))}
          >
            <option value="">All Roles</option>
            {roles.map(role => (
              <option key={role} value={role}>{role}</option>
            ))}
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Department</label>
          <select
            className={styles.filterSelect}
            value={filters.department}
            onChange={(e) => setFilters(prev => ({ ...prev, department: e.target.value }))}
          >
            <option value="">All Departments</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Status</label>
          <select
            className={styles.filterSelect}
            value={filters.status}
            onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
          >
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className={styles.usersTableContainer}>
        <div className={styles.tableHeader}>
          <h2 className={styles.tableTitle}>
            Users ({filteredUsers.length})
          </h2>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.usersTable}>
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>Department</th>
                <th>Status</th>
                <th>Last Login</th>
                <th>Expenses</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id}>
                  <td>
                    <div className={styles.userInfo}>
                      <div className={styles.userAvatar}>
                        <span className={styles.avatarText}>
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div className={styles.userDetails}>
                        <div className={styles.userName}>{user.name}</div>
                        <div className={styles.userEmail}>{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`${styles.roleBadge} ${getRoleColor(user.role)}`}>
                      {user.role}
                    </span>
                  </td>
                  <td className={styles.department}>{user.department}</td>
                  <td>
                    <span className={`${styles.statusBadge} ${getStatusColor(user.status)}`}>
                      {user.status}
                    </span>
                  </td>
                  <td className={styles.lastLogin}>
                    {new Date(user.lastLogin).toLocaleDateString()}
                  </td>
                  <td className={styles.expensesCount}>{user.expensesSubmitted}</td>
                  <td>
                    <div className={styles.actionButtons}>
                      <button 
                        className={styles.toggleButton}
                        onClick={() => handleToggleStatus(user.id)}
                      >
                        {user.status === 'active' ? 'Deactivate' : 'Activate'}
                      </button>
                      <button 
                        className={styles.editButton}
                      >
                        Edit
                      </button>
                      <button 
                        className={styles.deleteButton}
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Form Modal */}
      {showAddUserForm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>Add New User</h2>
              <button 
                className={styles.closeButton}
                onClick={() => setShowAddUserForm(false)}
              >
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <p className={styles.modalText}>
                User management form would be implemented here with fields for:
              </p>
              <ul className={styles.modalList}>
                <li>Full Name</li>
                <li>Email Address</li>
                <li>Role Selection</li>
                <li>Department Assignment</li>
                <li>Initial Permissions</li>
              </ul>
            </div>
            <div className={styles.modalActions}>
              <button 
                className={styles.cancelButton}
                onClick={() => setShowAddUserForm(false)}
              >
                Cancel
              </button>
              <button className={styles.saveButton}>
                Save User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagementPage;
