import React, { useState } from 'react';
import styles from './BudgetsPage.module.css';

const BudgetsPage = () => {
  const [budgets, setBudgets] = useState([
    {
      id: 1,
      category: 'Food & Dining',
      budgetAmount: 500.00,
      actualSpent: 275.50,
      currency: 'USD'
    },
    {
      id: 2,
      category: 'Transportation',
      budgetAmount: 300.00,
      actualSpent: 180.25,
      currency: 'USD'
    },
    {
      id: 3,
      category: 'Entertainment',
      budgetAmount: 200.00,
      actualSpent: 200.00,
      currency: 'USD'
    },
    {
      id: 4,
      category: 'Utilities',
      budgetAmount: 150.00,
      actualSpent: 95.75,
      currency: 'USD'
    },
    {
      id: 5,
      category: 'Office Supplies',
      budgetAmount: 100.00,
      actualSpent: 45.00,
      currency: 'USD'
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);

  const categories = [
    'Food & Dining',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Office Supplies',
    'Travel',
    'Healthcare',
    'Education',
    'Other'
  ];

  const calculateProgressPercentage = (actualSpent, budgetAmount) => {
    return Math.min((actualSpent / budgetAmount) * 100, 100);
  };

  const getProgressColor = (percentage) => {
    if (percentage >= 100) return styles.progressOver;
    if (percentage >= 80) return styles.progressWarning;
    return styles.progressGood;
  };

  const getStatusText = (percentage) => {
    if (percentage >= 100) return 'Over Budget';
    if (percentage >= 80) return 'Near Limit';
    return 'On Track';
  };

  const getStatusClass = (percentage) => {
    if (percentage >= 100) return styles.statusOver;
    if (percentage >= 80) return styles.statusWarning;
    return styles.statusGood;
  };

  const handleAddBudget = () => {
    setShowAddForm(true);
    setEditingBudget(null);
  };

  const handleEditBudget = (budget) => {
    setEditingBudget(budget);
    setShowAddForm(true);
  };

  const handleDeleteBudget = (budgetId) => {
    if (window.confirm('Are you sure you want to delete this budget?')) {
      setBudgets(prev => prev.filter(budget => budget.id !== budgetId));
    }
  };

  const handleSaveBudget = (budgetData) => {
    if (editingBudget) {
      // Edit existing budget
      setBudgets(prev => prev.map(budget => 
        budget.id === editingBudget.id 
          ? { ...budget, ...budgetData }
          : budget
      ));
    } else {
      // Add new budget
      const newBudget = {
        id: Math.max(...budgets.map(b => b.id)) + 1,
        ...budgetData,
        actualSpent: 0 // New budgets start with 0 spent
      };
      setBudgets(prev => [...prev, newBudget]);
    }
    setShowAddForm(false);
    setEditingBudget(null);
  };

  const handleCancelForm = () => {
    setShowAddForm(false);
    setEditingBudget(null);
  };

  return (
    <div className={styles.budgetsPage}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>Budgets</h1>
          <p className={styles.pageSubtitle}>Set and track spending limits per category</p>
        </div>
        <button 
          className={styles.addBudgetButton}
          onClick={handleAddBudget}
        >
          Add New Budget
        </button>
      </div>

      {/* Budgets Table */}
      <div className={styles.budgetsTableContainer}>
        <div className={styles.tableHeader}>
          <h2 className={styles.tableTitle}>Budget Overview ({budgets.length})</h2>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.budgetsTable}>
            <thead>
              <tr>
                <th>Category</th>
                <th>Budget Amount</th>
                <th>Actual Spent</th>
                <th>Progress</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {budgets.map((budget) => {
                const progressPercentage = calculateProgressPercentage(budget.actualSpent, budget.budgetAmount);
                const remainingAmount = budget.budgetAmount - budget.actualSpent;
                
                return (
                  <tr key={budget.id}>
                    <td>
                      <div className={styles.categoryInfo}>
                        <span className={styles.categoryName}>{budget.category}</span>
                      </div>
                    </td>
                    <td className={styles.budgetAmount}>
                      {budget.currency} {budget.budgetAmount.toFixed(2)}
                    </td>
                    <td className={styles.actualSpent}>
                      {budget.currency} {budget.actualSpent.toFixed(2)}
                    </td>
                    <td>
                      <div className={styles.progressContainer}>
                        <div className={styles.progressBar}>
                          <div 
                            className={`${styles.progressFill} ${getProgressColor(progressPercentage)}`}
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                        <span className={styles.progressText}>
                          {progressPercentage.toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td>
                      <span className={`${styles.statusBadge} ${getStatusClass(progressPercentage)}`}>
                        {getStatusText(progressPercentage)}
                      </span>
                    </td>
                    <td>
                      <div className={styles.actionButtons}>
                        <button 
                          className={styles.editButton}
                          onClick={() => handleEditBudget(budget)}
                        >
                          Edit
                        </button>
                        <button 
                          className={styles.deleteButton}
                          onClick={() => handleDeleteBudget(budget.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Budget Form Modal */}
      {showAddForm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h3 className={styles.modalTitle}>
                {editingBudget ? 'Edit Budget' : 'Add New Budget'}
              </h3>
              <button 
                className={styles.closeButton}
                onClick={handleCancelForm}
              >
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const budgetData = {
                  category: formData.get('category'),
                  budgetAmount: parseFloat(formData.get('budgetAmount')),
                  currency: formData.get('currency')
                };
                handleSaveBudget(budgetData);
              }}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Category</label>
                  <select
                    name="category"
                    className={styles.formSelect}
                    defaultValue={editingBudget?.category || ''}
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Budget Amount</label>
                  <input
                    type="number"
                    name="budgetAmount"
                    className={styles.formInput}
                    defaultValue={editingBudget?.budgetAmount || ''}
                    min="0"
                    step="0.01"
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Currency</label>
                  <select
                    name="currency"
                    className={styles.formSelect}
                    defaultValue={editingBudget?.currency || 'USD'}
                    required
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="CAD">CAD (C$)</option>
                  </select>
                </div>
                
                <div className={styles.formActions}>
                  <button 
                    type="button" 
                    className={styles.cancelButton}
                    onClick={handleCancelForm}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className={styles.saveButton}
                  >
                    {editingBudget ? 'Update Budget' : 'Create Budget'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BudgetsPage;