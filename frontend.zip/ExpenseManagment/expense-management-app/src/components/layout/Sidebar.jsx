import React from 'react';
import styles from './Sidebar.module.css';

const Sidebar = ({ currentPage, onPageChange, isOpen, onClose }) => {
  const navigationItems = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊' },
    { id: 'expenses', name: 'Expenses', icon: '💰' },
    { id: 'categories', name: 'Categories', icon: '📁' },
    { id: 'reports', name: 'Reports', icon: '📈' },
    { id: 'budgets', name: 'Budgets', icon: '💳' },
    { id: 'settings', name: 'Settings', icon: '⚙️' }
  ];

  const handleItemClick = (itemId) => {
    onPageChange(itemId);
    onClose();
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <div className={styles.sidebarDesktop}>
        <div className={styles.sidebarContent}>
          {/* Logo & Title Section */}
          <div className={styles.logoSection}>
            <div className={styles.logoIcon}>💰</div>
            <div className={styles.logoText}>
              <h1 className={styles.appTitle}>Great Goldfinch</h1>
              <p className={styles.appSubtitle}>Expense Management System</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className={styles.navigation}>
            <ul className={styles.navList}>
              {navigationItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => handleItemClick(item.id)}
                    className={`${styles.navItem} ${
                      currentPage === item.id ? styles.active : ''
                    }`}
                  >
                    <span className={styles.navIcon}>{item.icon}</span>
                    <span className={styles.navText}>{item.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* User Profile Section */}
          <div className={styles.userSection}>
            <div className={styles.userAvatar}>
              <span className={styles.avatarText}>JD</span>
            </div>
            <div className={styles.userInfo}>
              <p className={styles.userName}>John Doe</p>
              <p className={styles.userEmail}>john@company.com</p>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar */}
      <div className={`${styles.sidebarMobile} ${isOpen ? styles.open : ''}`}>
        <div className={styles.sidebarContent}>
          {/* Mobile Header */}
          <div className={styles.mobileHeader}>
            <div className={styles.logoSection}>
              <div className={styles.logoIcon}>💰</div>
              <div className={styles.logoText}>
                <h1 className={styles.appTitle}>Great Goldfinch</h1>
                <p className={styles.appSubtitle}>Expense Management</p>
              </div>
            </div>
            <button onClick={onClose} className={styles.closeButton}>
              ×
            </button>
          </div>

          {/* Mobile Navigation */}
          <nav className={styles.navigation}>
            <ul className={styles.navList}>
              {navigationItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => handleItemClick(item.id)}
                    className={`${styles.navItem} ${
                      currentPage === item.id ? styles.active : ''
                    }`}
                  >
                    <span className={styles.navIcon}>{item.icon}</span>
                    <span className={styles.navText}>{item.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Mobile User Section */}
          <div className={styles.userSection}>
            <div className={styles.userAvatar}>
              <span className={styles.avatarText}>JD</span>
            </div>
            <div className={styles.userInfo}>
              <p className={styles.userName}>John Doe</p>
              <p className={styles.userEmail}>john@company.com</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;