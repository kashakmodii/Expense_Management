import './Dashboard.css'

const Dashboard = () => {
  return (
    <div className="dashboard">
      {/* Page Header */}
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Welcome back! Here's what's happening with your expenses.</p>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-content">
            <div className="stat-icon primary">
              <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
              </svg>
            </div>
            <div className="stat-text">
              <p className="stat-label">Total Expenses</p>
              <p className="stat-value">$2,450.00</p>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-content">
            <div className="stat-icon success">
              <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="stat-text">
              <p className="stat-label">This Month</p>
              <p className="stat-value">$1,200.00</p>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-content">
            <div className="stat-icon error">
              <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <div className="stat-text">
              <p className="stat-label">Over Budget</p>
              <p className="stat-value">$150.00</p>
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-content">
            <div className="stat-icon secondary">
              <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <div className="stat-text">
              <p className="stat-label">Categories</p>
              <p className="stat-value">12</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Expenses */}
      <div className="recent-expenses">
        <div className="expenses-header">
          <h2 className="expenses-title">Recent Expenses</h2>
        </div>
        <div className="expenses-content">
          <div className="expenses-list">
            {[
              { name: 'Grocery Shopping', amount: '$85.50', date: 'Today', category: 'Food' },
              { name: 'Gas Station', amount: '$45.00', date: 'Yesterday', category: 'Transportation' },
              { name: 'Coffee Shop', amount: '$12.75', date: 'Yesterday', category: 'Food' },
              { name: 'Movie Tickets', amount: '$28.00', date: '2 days ago', category: 'Entertainment' },
            ].map((expense, index) => (
              <div key={index} className="expense-item">
                <div className="expense-info">
                  <div className="expense-icon">
                    <span className="expense-category-icon">
                      {expense.category.charAt(0)}
                    </span>
                  </div>
                  <div className="expense-details">
                    <p className="expense-name">{expense.name}</p>
                    <p className="expense-meta">{expense.category} • {expense.date}</p>
                  </div>
                </div>
                <div className="expense-amount">
                  <p className="expense-value">{expense.amount}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
