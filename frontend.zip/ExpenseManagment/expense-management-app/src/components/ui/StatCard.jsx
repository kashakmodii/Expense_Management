import React from 'react';
import styles from './StatCard.module.css';

const StatCard = ({ title, value, icon, color = 'primary', trend = null }) => {
  const getColorClass = () => {
    const colors = {
      primary: styles.primary,
      success: styles.success,
      warning: styles.warning,
      danger: styles.danger
    };
    return colors[color] || styles.primary;
  };

  return (
    <div className={`${styles.statCard} ${getColorClass()}`}>
      <div className={styles.statContent}>
        <div className={styles.statIcon}>
          <span className={styles.icon}>{icon}</span>
        </div>
        <div className={styles.statText}>
          <p className={styles.statLabel}>{title}</p>
          <p className={styles.statValue}>{value}</p>
          {trend && (
            <div className={styles.statTrend}>
              <span className={`${styles.trendIcon} ${trend.direction === 'up' ? styles.trendUp : styles.trendDown}`}>
                {trend.direction === 'up' ? '↗' : '↘'}
              </span>
              <span className={styles.trendValue}>{trend.value}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StatCard;
