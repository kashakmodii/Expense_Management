import React, { useState } from 'react';
import AppLayout from './components/layout/AppLayout';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import DashboardPage from './pages/DashboardPage';
import ExpensesPage from './pages/ExpensesPage';
import CategoriesPage from './pages/CategoriesPage';
import ReportsPage from './pages/ReportsPage';
import BudgetsPage from './pages/BudgetsPage';
import SettingsPage from './pages/SettingsPage';
import ApprovalQueuePage from './pages/ApprovalQueuePage';
import UserManagementPage from './pages/UserManagementPage';
import ApprovalRulesPage from './pages/ApprovalRulesPage';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Set to false for login flow
  const [userRole, setUserRole] = useState('manager'); // 'employee', 'manager', 'admin'

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onLogin={() => setIsAuthenticated(true)} />;
      case 'signup':
        return <SignupPage onSignup={() => setIsAuthenticated(true)} />;
      case 'dashboard':
        return <DashboardPage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'categories':
        return <CategoriesPage userRole={userRole} />;
      case 'reports':
        return <ReportsPage />;
      case 'budgets':
        return <BudgetsPage />;
      case 'settings':
        return <SettingsPage />;
      case 'approval-queue':
        return <ApprovalQueuePage />;
      case 'user-management':
        return <UserManagementPage />;
      case 'approval-rules':
        return <ApprovalRulesPage />;
      default:
        return <DashboardPage />;
    }
  };

  const handlePageChange = (pageId) => {
    // Check permissions for admin pages
    if (['approval-queue', 'user-management', 'approval-rules'].includes(pageId)) {
      if (userRole !== 'admin' && userRole !== 'manager') {
        alert('You do not have permission to access this page.');
        return;
      }
    }
    
    // Check permissions for categories page
    if (pageId === 'categories' && userRole === 'employee') {
      alert('You do not have permission to access the Categories page.');
      return;
    }
    
    setCurrentPage(pageId);
  };

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return (
      <div>
        {currentPage === 'signup' ? (
          <SignupPage onSignup={() => setIsAuthenticated(true)} />
        ) : (
          <LoginPage onLogin={() => setIsAuthenticated(true)} />
        )}
      </div>
    );
  }

  return (
    <AppLayout currentPage={currentPage} onPageChange={handlePageChange}>
      {renderPage()}
    </AppLayout>
  );
}

export default App;