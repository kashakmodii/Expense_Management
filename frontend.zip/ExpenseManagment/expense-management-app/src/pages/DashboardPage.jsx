import React from 'react';
import StatCard from '../components/ui/StatCard';
import RecentExpenseItem from '../components/ui/RecentExpenseItem';
import styles from './DashboardPage.module.css';

const DashboardPage = () => {
  const stats = [
    {
      title: 'Total Expenses',
      value: '$2,450.00',
      icon: '💰',
      color: 'primary',
      trend: { direction: 'up', value: '+12%' }
    },
    {
      title: 'This Month',
      value: '$1,200.00',
      icon: '📊',
      color: 'success',
      trend: { direction: 'up', value: '+8%' }
    },
    {
      title: 'Over Budget',
      value: '$150.00',
      icon: '⚠️',
      color: 'warning',
      trend: { direction: 'down', value: '-5%' }
    },
    {
      title: 'Categories',
      value: '12',
      icon: '📁',
      color: 'primary',
      trend: null
    }
  ];

  const recentExpenses = [
    {
      id: 1,
      name: 'Grocery Shopping',
      amount: '$85.50',
      date: '2024-01-15',
      category: 'Food',
      status: 'approved'
    },
    {
      id: 2,
      name: 'Gas Station',
      amount: '$45.00',
      date: '2024-01-14',
      category: 'Transportation',
      status: 'pending'
    },
    {
      id: 3,
      name: 'Coffee Shop',
      amount: '$12.75',
      date: '2024-01-14',
      category: 'Food',
      status: 'approved'
    },
    {
      id: 4,
      name: 'Movie Tickets',
      amount: '$28.00',
      date: '2024-01-13',
      category: 'Entertainment',
      status: 'rejected'
    },
    {
      id: 5,
      name: 'Office Supplies',
      amount: '$67.25',
      date: '2024-01-12',
      category: 'Office',
      status: 'approved'
    }
  ];

  return (
    <div className={styles.dashboard}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Dashboard</h1>
        <p className={styles.pageSubtitle}>
          Welcome back! Here's what's happening with your expenses.
        </p>
      </div>

      {/* Stats Grid */}
      <div className={styles.statsGrid}>
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            color={stat.color}
            trend={stat.trend}
          />
        ))}
      </div>

      {/* Recent Expenses */}
      <div className={styles.recentExpenses}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Recent Expenses</h2>
          <button className={styles.viewAllButton}>View All</button>
        </div>
        <div className={styles.expensesList}>
          {recentExpenses.map((expense) => (
            <RecentExpenseItem key={expense.id} expense={expense} />
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className={styles.quickActions}>
        <h2 className={styles.sectionTitle}>Quick Actions</h2>
        <div className={styles.actionButtons}>
          <button className={styles.actionButton}>
            <span className={styles.actionIcon}>➕</span>
            <span className={styles.actionText}>Add Expense</span>
          </button>
          <button className={styles.actionButton}>
            <span className={styles.actionIcon}>📊</span>
            <span className={styles.actionText}>View Reports</span>
          </button>
          <button className={styles.actionButton}>
            <span className={styles.actionIcon}>💳</span>
            <span className={styles.actionText}>Manage Budgets</span>
          </button>
          <button className={styles.actionButton}>
            <span className={styles.actionIcon}>📁</span>
            <span className={styles.actionText}>Categories</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
