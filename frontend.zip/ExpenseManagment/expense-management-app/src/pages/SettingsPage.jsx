import React, { useState } from 'react';
import styles from './SettingsPage.module.css';

const SettingsPage = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [userRole] = useState('Admin'); // This would typically come from context/auth
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);

  // Profile form state
  const [profileData, setProfileData] = useState({
    fullName: 'John Doe',
    email: 'john.doe@company.com'
  });

  // Company form state
  const [companyData, setCompanyData] = useState({
    companyName: 'Acme Corporation',
    defaultCurrency: 'USD'
  });

  // Change password form state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const currencies = [
    { code: 'USD', name: 'US Dollar ($)' },
    { code: 'EUR', name: 'Euro (€)' },
    { code: 'GBP', name: 'British Pound (£)' },
    { code: 'CAD', name: 'Canadian Dollar (C$)' },
    { code: 'AUD', name: 'Australian Dollar (A$)' },
    { code: 'JPY', name: 'Japanese Yen (¥)' }
  ];

  const handleProfileChange = (field, value) => {
    setProfileData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCompanyChange = (field, value) => {
    setCompanyData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePasswordChange = (field, value) => {
    setPasswordData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleUpdateProfile = (e) => {
    e.preventDefault();
    console.log('Updating profile:', profileData);
    // TODO: Implement profile update logic
    alert('Profile updated successfully!');
  };

  const handleSaveCompany = (e) => {
    e.preventDefault();
    console.log('Saving company settings:', companyData);
    // TODO: Implement company settings save logic
    alert('Company settings saved successfully!');
  };

  const handleChangePassword = (e) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('New passwords do not match!');
      return;
    }
    
    if (passwordData.newPassword.length < 8) {
      alert('New password must be at least 8 characters long!');
      return;
    }
    
    console.log('Changing password:', passwordData);
    // TODO: Implement password change logic
    alert('Password changed successfully!');
    setShowChangePasswordModal(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const handleCancelPasswordChange = () => {
    setShowChangePasswordModal(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  return (
    <div className={styles.settingsPage}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Settings</h1>
        <p className={styles.pageSubtitle}>
          Manage your account settings and preferences
        </p>
      </div>

      {/* Tabs */}
      <div className={styles.tabsContainer}>
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${activeTab === 'profile' ? styles.activeTab : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            Profile
          </button>
          {userRole === 'Admin' && (
            <button
              className={`${styles.tab} ${activeTab === 'company' ? styles.activeTab : ''}`}
              onClick={() => setActiveTab('company')}
            >
              Company
            </button>
          )}
        </div>
      </div>

      {/* Tab Content */}
      <div className={styles.tabContent}>
        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className={styles.profileTab}>
            <div className={styles.sectionCard}>
              <div className={styles.sectionHeader}>
                <h2 className={styles.sectionTitle}>Personal Information</h2>
                <p className={styles.sectionDescription}>
                  Update your personal details and account information
                </p>
              </div>
              
              <form onSubmit={handleUpdateProfile} className={styles.form}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Full Name</label>
                  <input
                    type="text"
                    className={styles.formInput}
                    value={profileData.fullName}
                    onChange={(e) => handleProfileChange('fullName', e.target.value)}
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Email Address</label>
                  <input
                    type="email"
                    className={styles.formInput}
                    value={profileData.email}
                    onChange={(e) => handleProfileChange('email', e.target.value)}
                    required
                  />
                </div>
                
                <div className={styles.formActions}>
                  <button type="submit" className={styles.updateButton}>
                    Update Profile
                  </button>
                </div>
              </form>
            </div>

            <div className={styles.sectionCard}>
              <div className={styles.sectionHeader}>
                <h2 className={styles.sectionTitle}>Security</h2>
                <p className={styles.sectionDescription}>
                  Manage your password and security settings
                </p>
              </div>
              
              <div className={styles.securityActions}>
                <button 
                  className={styles.changePasswordButton}
                  onClick={() => setShowChangePasswordModal(true)}
                >
                  Change Password
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Company Tab */}
        {activeTab === 'company' && userRole === 'Admin' && (
          <div className={styles.companyTab}>
            <div className={styles.sectionCard}>
              <div className={styles.sectionHeader}>
                <h2 className={styles.sectionTitle}>Company Settings</h2>
                <p className={styles.sectionDescription}>
                  Configure company-wide settings and preferences
                </p>
              </div>
              
              <form onSubmit={handleSaveCompany} className={styles.form}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Company Name</label>
                  <input
                    type="text"
                    className={styles.formInput}
                    value={companyData.companyName}
                    onChange={(e) => handleCompanyChange('companyName', e.target.value)}
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Default Currency</label>
                  <select
                    className={styles.formSelect}
                    value={companyData.defaultCurrency}
                    onChange={(e) => handleCompanyChange('defaultCurrency', e.target.value)}
                    required
                  >
                    {currencies.map(currency => (
                      <option key={currency.code} value={currency.code}>
                        {currency.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className={styles.formActions}>
                  <button type="submit" className={styles.saveButton}>
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Change Password Modal */}
      {showChangePasswordModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h3 className={styles.modalTitle}>Change Password</h3>
              <button 
                className={styles.closeButton}
                onClick={handleCancelPasswordChange}
              >
                ×
              </button>
            </div>
            
            <div className={styles.modalBody}>
              <form onSubmit={handleChangePassword} className={styles.form}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Current Password</label>
                  <input
                    type="password"
                    className={styles.formInput}
                    value={passwordData.currentPassword}
                    onChange={(e) => handlePasswordChange('currentPassword', e.target.value)}
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>New Password</label>
                  <input
                    type="password"
                    className={styles.formInput}
                    value={passwordData.newPassword}
                    onChange={(e) => handlePasswordChange('newPassword', e.target.value)}
                    required
                    minLength="8"
                  />
                  <small className={styles.formHelp}>
                    Password must be at least 8 characters long
                  </small>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Confirm New Password</label>
                  <input
                    type="password"
                    className={styles.formInput}
                    value={passwordData.confirmPassword}
                    onChange={(e) => handlePasswordChange('confirmPassword', e.target.value)}
                    required
                  />
                </div>
                
                <div className={styles.formActions}>
                  <button 
                    type="button" 
                    className={styles.cancelButton}
                    onClick={handleCancelPasswordChange}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className={styles.saveButton}
                  >
                    Change Password
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;
