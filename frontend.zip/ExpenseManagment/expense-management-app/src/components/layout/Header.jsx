import React, { useState } from 'react';
import styles from './Header.module.css';

const Header = ({ onMenuClick, currentPage }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const notifications = [
    { id: 1, message: 'New expense submitted for approval', time: '2 min ago', type: 'info' },
    { id: 2, message: 'Budget limit exceeded', time: '1 hour ago', type: 'warning' },
    { id: 3, message: 'Monthly report ready', time: '3 hours ago', type: 'success' }
  ];

  const getBreadcrumb = () => {
    const breadcrumbs = {
      dashboard: ['Dashboard', 'Overview'],
      expenses: ['Expenses', 'All Expenses'],
      categories: ['Categories', 'Manage Categories'],
      reports: ['Reports', 'Analytics'],
      budgets: ['Budgets', 'Budget Management'],
      settings: ['Settings', 'Account Settings']
    };
    return breadcrumbs[currentPage] || ['Dashboard', 'Overview'];
  };

  const breadcrumb = getBreadcrumb();

  return (
    <header className={styles.header}>
      <div className={styles.headerContent}>
        {/* Left side - Mobile menu button and breadcrumbs */}
        <div className={styles.headerLeft}>
          <button
            type="button"
            className={styles.menuButton}
            onClick={onMenuClick}
          >
            <span className={styles.menuIcon}>☰</span>
            <span className={styles.srOnly}>Open sidebar</span>
          </button>
          
          {/* Breadcrumb navigation */}
          <nav className={styles.breadcrumb}>
            <ol className={styles.breadcrumbList}>
              <li className={styles.breadcrumbItem}>
                <span className={styles.breadcrumbText}>{breadcrumb[0]}</span>
              </li>
              <li className={styles.breadcrumbSeparator}>›</li>
              <li className={styles.breadcrumbItem}>
                <span className={styles.breadcrumbCurrent}>{breadcrumb[1]}</span>
              </li>
            </ol>
          </nav>
        </div>

        {/* Right side - Search, notifications, profile */}
        <div className={styles.headerRight}>
          {/* Search */}
          <div className={styles.searchContainer}>
            <div className={styles.searchIcon}>🔍</div>
            <input
              type="text"
              className={styles.searchInput}
              placeholder="Search expenses..."
            />
          </div>

          {/* Notifications */}
          <div className={styles.notificationContainer}>
            <button
              type="button"
              className={styles.notificationButton}
              onClick={() => setShowNotifications(!showNotifications)}
            >
              <span className={styles.notificationIcon}>🔔</span>
              {notifications.length > 0 && (
                <span className={styles.notificationBadge}>
                  {notifications.length}
                </span>
              )}
            </button>

            {/* Notifications dropdown */}
            {showNotifications && (
              <div className={styles.notificationDropdown}>
                <div className={styles.notificationHeader}>
                  <h3 className={styles.notificationTitle}>Notifications</h3>
                </div>
                <div className={styles.notificationList}>
                  {notifications.map((notification) => (
                    <div key={notification.id} className={styles.notificationItem}>
                      <div className={styles.notificationContent}>
                        <p className={styles.notificationMessage}>{notification.message}</p>
                        <p className={styles.notificationTime}>{notification.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className={styles.notificationFooter}>
                  <button className={styles.viewAllButton}>View all notifications</button>
                </div>
              </div>
            )}
          </div>

          {/* Profile dropdown */}
          <div className={styles.profileContainer}>
            <button
              type="button"
              className={styles.profileButton}
              onClick={() => setShowProfile(!showProfile)}
            >
              <div className={styles.profileAvatar}>
                <span className={styles.profileAvatarText}>JD</span>
              </div>
              <span className={styles.profileName}>John Doe</span>
              <span className={styles.profileArrow}>▼</span>
            </button>

            {/* Profile dropdown */}
            {showProfile && (
              <div className={styles.profileDropdown}>
                <div className={styles.profileDropdownItem}>
                  <span className={styles.profileDropdownIcon}>👤</span>
                  Profile
                </div>
                <div className={styles.profileDropdownItem}>
                  <span className={styles.profileDropdownIcon}>⚙️</span>
                  Settings
                </div>
                <div className={styles.profileDropdownDivider}></div>
                <div className={styles.profileDropdownItem}>
                  <span className={styles.profileDropdownIcon}>🚪</span>
                  Logout
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;