import React, { useState } from 'react';
import styles from './ExpenseForm.module.css';

const ExpenseForm = ({ onSubmit, onCancel, initialData = {} }) => {
  const [formData, setFormData] = useState({
    amount: initialData.amount || '',
    currency: initialData.currency || 'USD',
    category: initialData.category || '',
    description: initialData.description || '',
    date: initialData.date || new Date().toISOString().split('T')[0],
    receipt: null,
    ...initialData
  });

  const [errors, setErrors] = useState({});

  const categories = [
    'Food & Dining',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Office Supplies',
    'Travel',
    'Healthcare',
    'Education',
    'Other'
  ];

  const currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'];

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: files ? files[0] : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.amount || formData.amount <= 0) {
      newErrors.amount = 'Amount is required and must be greater than 0';
    }
    
    if (!formData.category) {
      newErrors.category = 'Category is required';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!formData.date) {
      newErrors.date = 'Date is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <div className={styles.formContainer}>
      <div className={styles.formHeader}>
        <h2 className={styles.formTitle}>Submit New Expense</h2>
        <button 
          type="button" 
          className={styles.closeButton}
          onClick={onCancel}
        >
          ×
        </button>
      </div>
      
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.formGrid}>
          {/* Amount */}
          <div className={styles.inputGroup}>
            <label htmlFor="amount" className={styles.label}>
              Amount *
            </label>
            <div className={styles.amountContainer}>
              <input
                type="number"
                id="amount"
                name="amount"
                className={`${styles.input} ${errors.amount ? styles.inputError : ''}`}
                placeholder="0.00"
                step="0.01"
                min="0"
                value={formData.amount}
                onChange={handleChange}
              />
              <select
                name="currency"
                className={styles.currencySelect}
                value={formData.currency}
                onChange={handleChange}
              >
                {currencies.map(currency => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
            </div>
            {errors.amount && <span className={styles.errorText}>{errors.amount}</span>}
          </div>

          {/* Category */}
          <div className={styles.inputGroup}>
            <label htmlFor="category" className={styles.label}>
              Category *
            </label>
            <select
              id="category"
              name="category"
              className={`${styles.select} ${errors.category ? styles.inputError : ''}`}
              value={formData.category}
              onChange={handleChange}
            >
              <option value="">Select a category</option>
              {categories.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
            {errors.category && <span className={styles.errorText}>{errors.category}</span>}
          </div>

          {/* Date */}
          <div className={styles.inputGroup}>
            <label htmlFor="date" className={styles.label}>
              Date *
            </label>
            <input
              type="date"
              id="date"
              name="date"
              className={`${styles.input} ${errors.date ? styles.inputError : ''}`}
              value={formData.date}
              onChange={handleChange}
            />
            {errors.date && <span className={styles.errorText}>{errors.date}</span>}
          </div>

          {/* Receipt Upload */}
          <div className={styles.inputGroup}>
            <label htmlFor="receipt" className={styles.label}>
              Receipt
            </label>
            <div className={styles.fileUpload}>
              <input
                type="file"
                id="receipt"
                name="receipt"
                className={styles.fileInput}
                accept="image/*,.pdf"
                onChange={handleChange}
              />
              <label htmlFor="receipt" className={styles.fileLabel}>
                <span className={styles.fileIcon}>📎</span>
                <span className={styles.fileText}>
                  {formData.receipt ? formData.receipt.name : 'Choose file or drag here'}
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className={styles.inputGroup}>
          <label htmlFor="description" className={styles.label}>
            Description *
          </label>
          <textarea
            id="description"
            name="description"
            className={`${styles.textarea} ${errors.description ? styles.inputError : ''}`}
            placeholder="Enter expense description..."
            rows="3"
            value={formData.description}
            onChange={handleChange}
          />
          {errors.description && <span className={styles.errorText}>{errors.description}</span>}
        </div>

        {/* Form Actions */}
        <div className={styles.formActions}>
          <button
            type="button"
            className={styles.cancelButton}
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            type="submit"
            className={styles.submitButton}
          >
            Submit Expense
          </button>
        </div>
      </form>
    </div>
  );
};

export default ExpenseForm;
