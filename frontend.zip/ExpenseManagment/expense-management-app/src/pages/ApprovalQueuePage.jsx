import React, { useState } from 'react';
import styles from './ApprovalQueuePage.module.css';

const ApprovalQueuePage = () => {
  const [expenses, setExpenses] = useState([
    {
      id: 1,
      name: 'Client Dinner',
      amount: 125.50,
      currency: 'USD',
      date: '2024-01-15',
      category: 'Food & Dining',
      description: 'Business dinner with potential client',
      submittedBy: 'John Doe',
      submittedDate: '2024-01-15',
      priority: 'high',
      approver: 'Sarah Johnson'
    },
    {
      id: 2,
      name: 'Conference Registration',
      amount: 450.00,
      currency: 'USD',
      date: '2024-01-14',
      category: 'Education',
      description: 'Tech conference registration fee',
      submittedBy: 'Mike Smith',
      submittedDate: '2024-01-14',
      priority: 'medium',
      approver: 'Sarah Johnson'
    },
    {
      id: 3,
      name: 'Office Equipment',
      amount: 89.99,
      currency: 'USD',
      date: '2024-01-13',
      category: 'Office Supplies',
      description: 'New wireless mouse and keyboard',
      submittedBy: 'Lisa Brown',
      submittedDate: '2024-01-13',
      priority: 'low',
      approver: 'David Wilson'
    },
    {
      id: 4,
      name: 'Travel Expenses',
      amount: 320.75,
      currency: 'USD',
      date: '2024-01-12',
      category: 'Travel',
      description: 'Flight and hotel for business trip',
      submittedBy: 'Alex Johnson',
      submittedDate: '2024-01-12',
      priority: 'high',
      approver: 'Sarah Johnson'
    }
  ]);

  const [filters, setFilters] = useState({
    search: '',
    priority: '',
    approver: '',
    dateRange: ''
  });

  const getPriorityColor = (priority) => {
    const colors = {
      'high': styles.priorityHigh,
      'medium': styles.priorityMedium,
      'low': styles.priorityLow
    };
    return colors[priority] || styles.priorityDefault;
  };

  const handleApprove = (expenseId) => {
    setExpenses(prev => prev.filter(expense => expense.id !== expenseId));
    console.log(`Approved expense ${expenseId}`);
  };

  const handleReject = (expenseId) => {
    setExpenses(prev => prev.filter(expense => expense.id !== expenseId));
    console.log(`Rejected expense ${expenseId}`);
  };

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                         expense.description.toLowerCase().includes(filters.search.toLowerCase()) ||
                         expense.submittedBy.toLowerCase().includes(filters.search.toLowerCase());
    const matchesPriority = !filters.priority || expense.priority === filters.priority;
    const matchesApprover = !filters.approver || expense.approver === filters.approver;
    
    return matchesSearch && matchesPriority && matchesApprover;
  });

  return (
    <div className={styles.approvalQueue}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>Approval Queue</h1>
          <p className={styles.pageSubtitle}>
            Review and approve pending expense requests
          </p>
        </div>
        <div className={styles.queueStats}>
          <div className={styles.statItem}>
            <span className={styles.statValue}>{expenses.length}</span>
            <span className={styles.statLabel}>Pending</span>
          </div>
          <div className={styles.statItem}>
            <span className={styles.statValue}>
              {expenses.filter(e => e.priority === 'high').length}
            </span>
            <span className={styles.statLabel}>High Priority</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className={styles.filtersSection}>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Search</label>
          <input
            type="text"
            placeholder="Search expenses..."
            className={styles.filterInput}
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
          />
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Priority</label>
          <select
            className={styles.filterSelect}
            value={filters.priority}
            onChange={(e) => setFilters(prev => ({ ...prev, priority: e.target.value }))}
          >
            <option value="">All Priorities</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Approver</label>
          <select
            className={styles.filterSelect}
            value={filters.approver}
            onChange={(e) => setFilters(prev => ({ ...prev, approver: e.target.value }))}
          >
            <option value="">All Approvers</option>
            <option value="Sarah Johnson">Sarah Johnson</option>
            <option value="David Wilson">David Wilson</option>
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Date Range</label>
          <select
            className={styles.filterSelect}
            value={filters.dateRange}
            onChange={(e) => setFilters(prev => ({ ...prev, dateRange: e.target.value }))}
          >
            <option value="">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
        </div>
      </div>

      {/* Approval Queue Table */}
      <div className={styles.queueTableContainer}>
        <div className={styles.tableHeader}>
          <h2 className={styles.tableTitle}>
            Pending Approvals ({filteredExpenses.length})
          </h2>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.queueTable}>
            <thead>
              <tr>
                <th>Expense Details</th>
                <th>Amount</th>
                <th>Submitted By</th>
                <th>Priority</th>
                <th>Assigned To</th>
                <th>Submitted Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredExpenses.map((expense) => (
                <tr key={expense.id}>
                  <td>
                    <div className={styles.expenseDetails}>
                      <div className={styles.expenseName}>{expense.name}</div>
                      <div className={styles.expenseDesc}>{expense.description}</div>
                      <div className={styles.expenseMeta}>
                        {expense.category} • {new Date(expense.date).toLocaleDateString()}
                      </div>
                    </div>
                  </td>
                  <td className={styles.expenseAmount}>
                    {expense.currency} {expense.amount.toFixed(2)}
                  </td>
                  <td className={styles.submittedBy}>{expense.submittedBy}</td>
                  <td>
                    <span className={`${styles.priorityBadge} ${getPriorityColor(expense.priority)}`}>
                      {expense.priority}
                    </span>
                  </td>
                  <td className={styles.approver}>{expense.approver}</td>
                  <td className={styles.submittedDate}>
                    {new Date(expense.submittedDate).toLocaleDateString()}
                  </td>
                  <td>
                    <div className={styles.actionButtons}>
                      <button 
                        className={styles.approveButton}
                        onClick={() => handleApprove(expense.id)}
                      >
                        Approve
                      </button>
                      <button 
                        className={styles.rejectButton}
                        onClick={() => handleReject(expense.id)}
                      >
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bulk Actions */}
      <div className={styles.bulkActions}>
        <div className={styles.bulkActionsContent}>
          <span className={styles.bulkActionsLabel}>Bulk Actions:</span>
          <button className={styles.bulkApproveButton}>
            Approve Selected
          </button>
          <button className={styles.bulkRejectButton}>
            Reject Selected
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApprovalQueuePage;
