import React, { useState } from 'react';
import ExpenseForm from '../components/ui/ExpenseForm';
import styles from './ExpensesPage.module.css';

const ExpensesPage = () => {
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [expenses, setExpenses] = useState([
    {
      id: 1,
      name: 'Grocery Shopping',
      amount: 85.50,
      currency: 'USD',
      date: '2024-01-15',
      category: 'Food & Dining',
      description: 'Weekly grocery shopping at Walmart',
      status: 'approved',
      submittedBy: 'John Doe'
    },
    {
      id: 2,
      name: 'Gas Station',
      amount: 45.00,
      currency: 'USD',
      date: '2024-01-14',
      category: 'Transportation',
      description: 'Fuel for car',
      status: 'pending',
      submittedBy: 'John Doe'
    },
    {
      id: 3,
      name: 'Coffee Shop',
      amount: 12.75,
      currency: 'USD',
      date: '2024-01-14',
      category: 'Food & Dining',
      description: 'Morning coffee',
      status: 'approved',
      submittedBy: 'John Doe'
    },
    {
      id: 4,
      name: 'Movie Tickets',
      amount: 28.00,
      currency: 'USD',
      date: '2024-01-13',
      category: 'Entertainment',
      description: 'Weekend movie with friends',
      status: 'rejected',
      submittedBy: 'John Doe'
    },
    {
      id: 5,
      name: 'Electric Bill',
      amount: 120.50,
      currency: 'USD',
      date: '2024-01-12',
      category: 'Utilities',
      description: 'Monthly electricity bill',
      status: 'approved',
      submittedBy: 'John Doe'
    }
  ]);

  const [filters, setFilters] = useState({
    search: '',
    category: '',
    status: '',
    dateRange: ''
  });

  const categories = [
    'Food & Dining',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Office Supplies',
    'Travel',
    'Healthcare',
    'Education',
    'Other'
  ];

  const getCategoryColor = (category) => {
    const colors = {
      'Food & Dining': styles.categoryFood,
      'Transportation': styles.categoryTransportation,
      'Entertainment': styles.categoryEntertainment,
      'Utilities': styles.categoryUtilities,
      'Office Supplies': styles.categoryOffice,
      'Travel': styles.categoryTravel,
      'Healthcare': styles.categoryHealthcare,
      'Education': styles.categoryEducation,
      'Other': styles.categoryOther
    };
    return colors[category] || styles.categoryDefault;
  };

  const getStatusColor = (status) => {
    const colors = {
      'approved': styles.statusApproved,
      'pending': styles.statusPending,
      'rejected': styles.statusRejected,
      'draft': styles.statusDraft
    };
    return colors[status] || styles.statusDefault;
  };

  const handleExpenseSubmit = (expenseData) => {
    const newExpense = {
      id: expenses.length + 1,
      ...expenseData,
      status: 'pending',
      submittedBy: 'John Doe'
    };
    setExpenses(prev => [newExpense, ...prev]);
    setShowExpenseForm(false);
  };

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                         expense.description.toLowerCase().includes(filters.search.toLowerCase());
    const matchesCategory = !filters.category || expense.category === filters.category;
    const matchesStatus = !filters.status || expense.status === filters.status;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className={styles.expensesPage}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>Expenses</h1>
          <p className={styles.pageSubtitle}>Manage and track your expenses</p>
        </div>
        <button 
          className={styles.addExpenseButton}
          onClick={() => setShowExpenseForm(true)}
        >
          Submit New Expense
        </button>
      </div>

      {/* Filters */}
      <div className={styles.filtersSection}>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Search</label>
          <input
            type="text"
            placeholder="Search expenses..."
            className={styles.filterInput}
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
          />
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Category</label>
          <select
            className={styles.filterSelect}
            value={filters.category}
            onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
          >
            <option value="">All Categories</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Status</label>
          <select
            className={styles.filterSelect}
            value={filters.status}
            onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
          >
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="draft">Draft</option>
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label className={styles.filterLabel}>Date Range</label>
          <select
            className={styles.filterSelect}
            value={filters.dateRange}
            onChange={(e) => setFilters(prev => ({ ...prev, dateRange: e.target.value }))}
          >
            <option value="">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="quarter">This Quarter</option>
            <option value="year">This Year</option>
          </select>
        </div>
      </div>

      {/* Expenses Table */}
      <div className={styles.expensesTableContainer}>
        <div className={styles.tableHeader}>
          <h2 className={styles.tableTitle}>All Expenses ({filteredExpenses.length})</h2>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.expensesTable}>
            <thead>
              <tr>
                <th>Description</th>
                <th>Category</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Status</th>
                <th>Submitted By</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredExpenses.map((expense) => (
                <tr key={expense.id}>
                  <td>
                    <div className={styles.expenseDescription}>
                      <div className={styles.expenseName}>{expense.name}</div>
                      <div className={styles.expenseDesc}>{expense.description}</div>
                    </div>
                  </td>
                  <td>
                    <span className={`${styles.categoryBadge} ${getCategoryColor(expense.category)}`}>
                      {expense.category}
                    </span>
                  </td>
                  <td className={styles.expenseAmount}>
                    {expense.currency} {expense.amount.toFixed(2)}
                  </td>
                  <td className={styles.expenseDate}>
                    {new Date(expense.date).toLocaleDateString()}
                  </td>
                  <td>
                    <span className={`${styles.statusBadge} ${getStatusColor(expense.status)}`}>
                      {expense.status}
                    </span>
                  </td>
                  <td className={styles.submittedBy}>{expense.submittedBy}</td>
                  <td>
                    <div className={styles.actionButtons}>
                      <button className={styles.editButton}>Edit</button>
                      <button className={styles.deleteButton}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Expense Form Modal */}
      {showExpenseForm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <ExpenseForm
              onSubmit={handleExpenseSubmit}
              onCancel={() => setShowExpenseForm(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpensesPage;
