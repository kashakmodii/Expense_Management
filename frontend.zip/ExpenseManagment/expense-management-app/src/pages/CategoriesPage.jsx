import React, { useState } from 'react';
import styles from './CategoriesPage.module.css';

const CategoriesPage = ({ userRole }) => {
  const [categories, setCategories] = useState([
    {
      id: 1,
      name: 'Food & Dining',
      description: 'Meals, groceries, and dining expenses',
      color: '#10b981',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 45
    },
    {
      id: 2,
      name: 'Transportation',
      description: 'Gas, public transport, and vehicle expenses',
      color: '#3b82f6',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 23
    },
    {
      id: 3,
      name: 'Entertainment',
      description: 'Movies, games, and recreational activities',
      color: '#8b5cf6',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 12
    },
    {
      id: 4,
      name: 'Utilities',
      description: 'Electricity, water, internet, and phone bills',
      color: '#f59e0b',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 8
    },
    {
      id: 5,
      name: 'Office Supplies',
      description: 'Stationery, equipment, and office materials',
      color: '#ef4444',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 15
    },
    {
      id: 6,
      name: 'Travel',
      description: 'Business trips, accommodation, and travel expenses',
      color: '#06b6d4',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 6
    },
    {
      id: 7,
      name: 'Healthcare',
      description: 'Medical expenses, prescriptions, and health services',
      color: '#84cc16',
      isActive: true,
      createdAt: '2024-01-01',
      expenseCount: 4
    },
    {
      id: 8,
      name: 'Education',
      description: 'Training, courses, and educational materials',
      color: '#f97316',
      isActive: false,
      createdAt: '2024-01-01',
      expenseCount: 2
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [filters, setFilters] = useState({
    search: '',
    status: ''
  });

  // Check if user has permission to manage categories
  const canManageCategories = userRole === 'admin';

  const handleAddCategory = () => {
    setShowAddForm(true);
    setEditingCategory(null);
  };

  const handleEditCategory = (category) => {
    setEditingCategory(category);
    setShowAddForm(true);
  };

  const handleDeleteCategory = (categoryId) => {
    if (window.confirm('Are you sure you want to delete this category? This action cannot be undone.')) {
      setCategories(prev => prev.filter(category => category.id !== categoryId));
    }
  };

  const handleSaveCategory = (categoryData) => {
    if (editingCategory) {
      // Edit existing category
      setCategories(prev => prev.map(category => 
        category.id === editingCategory.id 
          ? { ...category, ...categoryData }
          : category
      ));
    } else {
      // Add new category
      const newCategory = {
        id: Math.max(...categories.map(c => c.id)) + 1,
        ...categoryData,
        createdAt: new Date().toISOString().split('T')[0],
        expenseCount: 0
      };
      setCategories(prev => [...prev, newCategory]);
    }
    setShowAddForm(false);
    setEditingCategory(null);
  };

  const handleCancelForm = () => {
    setShowAddForm(false);
    setEditingCategory(null);
  };

  const filteredCategories = categories.filter(category => {
    const matchesSearch = category.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                         category.description.toLowerCase().includes(filters.search.toLowerCase());
    const matchesStatus = !filters.status || 
                         (filters.status === 'active' && category.isActive) ||
                         (filters.status === 'inactive' && !category.isActive);
    
    return matchesSearch && matchesStatus;
  });

  // If user is Employee, show access denied message
  if (userRole === 'employee') {
    return (
      <div className={styles.accessDenied}>
        <div className={styles.accessDeniedContent}>
          <div className={styles.accessDeniedIcon}>🚫</div>
          <h2 className={styles.accessDeniedTitle}>Access Denied</h2>
          <p className={styles.accessDeniedMessage}>
            You don't have permission to access the Categories management page. 
            Please contact your administrator if you need access.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.categoriesPage}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <div className={styles.pageTitleSection}>
          <h1 className={styles.pageTitle}>Categories</h1>
          <p className={styles.pageSubtitle}>
            {userRole === 'admin' 
              ? 'Manage expense categories and their settings'
              : 'View available expense categories'
            }
          </p>
        </div>
        {canManageCategories && (
          <button 
            className={styles.addCategoryButton}
            onClick={handleAddCategory}
          >
            Add New Category
          </button>
        )}
      </div>

      {/* Filters - Only show for Admin and Manager */}
      {(userRole === 'admin' || userRole === 'manager') && (
        <div className={styles.filtersSection}>
          <div className={styles.filterGroup}>
            <label className={styles.filterLabel}>Search</label>
            <input
              type="text"
              placeholder="Search categories..."
              className={styles.filterInput}
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            />
          </div>
          <div className={styles.filterGroup}>
            <label className={styles.filterLabel}>Status</label>
            <select
              className={styles.filterSelect}
              value={filters.status}
              onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
            >
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      )}

      {/* Categories Table */}
      <div className={styles.categoriesTableContainer}>
        <div className={styles.tableHeader}>
          <h2 className={styles.tableTitle}>
            Categories ({filteredCategories.length})
          </h2>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.categoriesTable}>
            <thead>
              <tr>
                <th>Category</th>
                <th>Description</th>
                <th>Status</th>
                <th>Expense Count</th>
                <th>Created</th>
                {canManageCategories && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filteredCategories.map((category) => (
                <tr key={category.id}>
                  <td>
                    <div className={styles.categoryInfo}>
                      <div 
                        className={styles.categoryColor}
                        style={{ backgroundColor: category.color }}
                      ></div>
                      <span className={styles.categoryName}>{category.name}</span>
                    </div>
                  </td>
                  <td className={styles.categoryDescription}>
                    {category.description}
                  </td>
                  <td>
                    <span className={`${styles.statusBadge} ${category.isActive ? styles.statusActive : styles.statusInactive}`}>
                      {category.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className={styles.expenseCount}>
                    {category.expenseCount}
                  </td>
                  <td className={styles.createdDate}>
                    {new Date(category.createdAt).toLocaleDateString()}
                  </td>
                  {canManageCategories && (
                    <td>
                      <div className={styles.actionButtons}>
                        <button 
                          className={styles.editButton}
                          onClick={() => handleEditCategory(category)}
                        >
                          Edit
                        </button>
                        <button 
                          className={styles.deleteButton}
                          onClick={() => handleDeleteCategory(category.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Category Form Modal - Only for Admin */}
      {showAddForm && canManageCategories && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h3 className={styles.modalTitle}>
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button 
                className={styles.closeButton}
                onClick={handleCancelForm}
              >
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const categoryData = {
                  name: formData.get('name'),
                  description: formData.get('description'),
                  color: formData.get('color'),
                  isActive: formData.get('isActive') === 'on'
                };
                handleSaveCategory(categoryData);
              }}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Category Name</label>
                  <input
                    type="text"
                    name="name"
                    className={styles.formInput}
                    defaultValue={editingCategory?.name || ''}
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Description</label>
                  <textarea
                    name="description"
                    className={styles.formTextarea}
                    defaultValue={editingCategory?.description || ''}
                    rows="3"
                    required
                  />
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Color</label>
                  <div className={styles.colorInputGroup}>
                    <input
                      type="color"
                      name="color"
                      className={styles.colorInput}
                      defaultValue={editingCategory?.color || '#3b82f6'}
                    />
                    <input
                      type="text"
                      className={styles.colorTextInput}
                      defaultValue={editingCategory?.color || '#3b82f6'}
                      onChange={(e) => {
                        const colorInput = e.target.parentElement.querySelector('input[type="color"]');
                        if (colorInput) colorInput.value = e.target.value;
                      }}
                    />
                  </div>
                </div>
                
                <div className={styles.formGroup}>
                  <label className={styles.checkboxLabel}>
                    <input
                      type="checkbox"
                      name="isActive"
                      className={styles.checkbox}
                      defaultChecked={editingCategory?.isActive !== false}
                    />
                    <span className={styles.checkboxText}>Active</span>
                  </label>
                </div>
                
                <div className={styles.formActions}>
                  <button 
                    type="button" 
                    className={styles.cancelButton}
                    onClick={handleCancelForm}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className={styles.saveButton}
                  >
                    {editingCategory ? 'Update Category' : 'Create Category'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoriesPage;
