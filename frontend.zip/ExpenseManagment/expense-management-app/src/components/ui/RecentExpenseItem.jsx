import React from 'react';
import styles from './RecentExpenseItem.module.css';

const RecentExpenseItem = ({ expense }) => {
  const getCategoryColor = (category) => {
    const colors = {
      'Food': styles.categoryFood,
      'Transportation': styles.categoryTransportation,
      'Entertainment': styles.categoryEntertainment,
      'Utilities': styles.categoryUtilities,
      'Office': styles.categoryOffice,
      'Travel': styles.categoryTravel
    };
    return colors[category] || styles.categoryDefault;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className={styles.expenseItem}>
      <div className={styles.expenseInfo}>
        <div className={`${styles.expenseIcon} ${getCategoryColor(expense.category)}`}>
          <span className={styles.categoryIcon}>
            {expense.category.charAt(0)}
          </span>
        </div>
        <div className={styles.expenseDetails}>
          <p className={styles.expenseName}>{expense.name}</p>
          <p className={styles.expenseMeta}>
            {expense.category} • {formatDate(expense.date)}
          </p>
        </div>
      </div>
      <div className={styles.expenseAmount}>
        <p className={styles.expenseValue}>{expense.amount}</p>
        <div className={styles.expenseStatus}>
          <span className={`${styles.statusBadge} ${styles[expense.status]}`}>
            {expense.status}
          </span>
        </div>
      </div>
    </div>
  );
};

export default RecentExpenseItem;
