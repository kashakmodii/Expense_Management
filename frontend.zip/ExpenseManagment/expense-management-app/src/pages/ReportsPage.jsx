import React, { useState } from 'react';
import styles from './ReportsPage.module.css';

const ReportsPage = () => {
  const [filters, setFilters] = useState({
    dateRange: '',
    category: '',
    status: ''
  });

  const categories = [
    'Food & Dining',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Office Supplies',
    'Travel',
    'Healthcare',
    'Education',
    'Other'
  ];

  const statuses = [
    'All Status',
    'Pending',
    'Approved',
    'Rejected',
    'Draft'
  ];

  const dateRanges = [
    'All Time',
    'Today',
    'This Week',
    'This Month',
    'This Quarter',
    'This Year',
    'Last Month',
    'Last Quarter',
    'Last Year',
    'Custom Range'
  ];

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  const handleGenerateReport = () => {
    // Placeholder for report generation logic
    console.log('Generating report with filters:', filters);
    // TODO: Implement report generation logic
  };

  return (
    <div className={styles.reportsPage}>
      {/* Page Header */}
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Expense Reports</h1>
        <p className={styles.pageSubtitle}>
          Generate detailed reports and analytics for your expenses
        </p>
      </div>

      {/* Filter Controls */}
      <div className={styles.filtersSection}>
        <div className={styles.filtersContainer}>
          <div className={styles.filterGroup}>
            <label className={styles.filterLabel}>Date Range</label>
            <select
              className={styles.filterSelect}
              value={filters.dateRange}
              onChange={(e) => handleFilterChange('dateRange', e.target.value)}
            >
              {dateRanges.map(range => (
                <option key={range} value={range.toLowerCase().replace(' ', '_')}>
                  {range}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.filterGroup}>
            <label className={styles.filterLabel}>Category</label>
            <select
              className={styles.filterSelect}
              value={filters.category}
              onChange={(e) => handleFilterChange('category', e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.filterGroup}>
            <label className={styles.filterLabel}>Status</label>
            <select
              className={styles.filterSelect}
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
            >
              {statuses.map(status => (
                <option key={status} value={status.toLowerCase().replace(' ', '_')}>
                  {status}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.filterGroup}>
            <button 
              className={styles.generateButton}
              onClick={handleGenerateReport}
            >
              Generate Report
            </button>
          </div>
        </div>
      </div>

      {/* Report Content Placeholder */}
      <div className={styles.reportContent}>
        <div className={styles.placeholderSection}>
          <div className={styles.placeholderIcon}>📊</div>
          <h2 className={styles.placeholderTitle}>Report data will be displayed here</h2>
          <p className={styles.placeholderDescription}>
            Select your filters above and click "Generate Report" to view detailed analytics, 
            charts, and tables for your expense data.
          </p>
          <div className={styles.placeholderFeatures}>
            <div className={styles.featureItem}>
              <span className={styles.featureIcon}>📈</span>
              <span className={styles.featureText}>Interactive Charts</span>
            </div>
            <div className={styles.featureItem}>
              <span className={styles.featureIcon}>📋</span>
              <span className={styles.featureText}>Detailed Tables</span>
            </div>
            <div className={styles.featureItem}>
              <span className={styles.featureIcon}>💾</span>
              <span className={styles.featureText}>Export Options</span>
            </div>
            <div className={styles.featureItem}>
              <span className={styles.featureIcon}>🔍</span>
              <span className={styles.featureText}>Advanced Analytics</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;
