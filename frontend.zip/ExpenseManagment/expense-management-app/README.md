# Expense Management App

A modern React application built with Vite and Tailwind CSS, featuring a custom color theme.

## Features

- ⚡ **Vite** - Fast build tool and development server
- ⚛️ **React 18** - Modern React with hooks
- 🎨 **Tailwind CSS** - Utility-first CSS framework
- 🎨 **Custom Color Theme** - Modern blue primary, gray secondary, green success, red error

## Color Theme

The application uses a carefully designed color palette:

- **Primary (Blue)**: Modern blue shades for main actions and branding
- **Secondary (Gray)**: Light gray tones for backgrounds and subtle elements
- **Success (Green)**: Green shades for success states and positive actions
- **Error (Red)**: Red shades for error states and destructive actions

## Getting Started

### Prerequisites

- Node.js (version 16 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd expense-management-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build the application for production
- `npm run preview` - Preview the production build locally
- `npm run lint` - Run ESLint to check for code quality issues

## Project Structure

```
src/
├── App.jsx          # Main application component
├── index.css        # Global styles with Tailwind imports
├── index.js         # Application entry point
└── assets/          # Static assets
```

## Tailwind Configuration

The custom color theme is configured in `tailwind.config.js`:

- `primary-*` - Blue color variants (50-950)
- `secondary-*` - Gray color variants (50-950)
- `success-*` - Green color variants (50-950)
- `error-*` - Red color variants (50-950)

## Usage Examples

### Primary Colors
```jsx
<button className="bg-primary-500 hover:bg-primary-600 text-white">
  Primary Button
</button>
```

### Secondary Colors
```jsx
<div className="bg-secondary-100 text-secondary-800">
  Secondary Content
</div>
```

### Success States
```jsx
<div className="bg-success-100 border border-success-300 text-success-800">
  Success Message
</div>
```

### Error States
```jsx
<div className="bg-error-100 border border-error-300 text-error-800">
  Error Message
</div>
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.