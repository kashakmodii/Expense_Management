import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import styles from './AppLayout.module.css';

const AppLayout = ({ children, currentPage, onPageChange }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className={styles.appLayout}>
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className={styles.sidebarOverlay}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)}
        currentPage={currentPage}
        onPageChange={onPageChange}
      />

      {/* Main content area */}
      <div className={styles.mainContent}>
        {/* Header */}
        <Header 
          onMenuClick={() => setSidebarOpen(true)}
          currentPage={currentPage}
        />
        
        {/* Main content */}
        <main className={styles.mainWrapper}>
          <div className={styles.contentContainer}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;