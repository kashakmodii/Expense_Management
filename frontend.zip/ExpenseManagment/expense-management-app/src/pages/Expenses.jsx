import './Expenses.css'

const Expenses = () => {
  const expenses = [
    { id: 1, name: 'Grocery Shopping', amount: 85.50, date: '2024-01-15', category: 'Food', description: 'Weekly grocery shopping at Walmart' },
    { id: 2, name: 'Gas Station', amount: 45.00, date: '2024-01-14', category: 'Transportation', description: 'Fuel for car' },
    { id: 3, name: 'Coffee Shop', amount: 12.75, date: '2024-01-14', category: 'Food', description: 'Morning coffee' },
    { id: 4, name: 'Movie Tickets', amount: 28.00, date: '2024-01-13', category: 'Entertainment', description: 'Weekend movie with friends' },
    { id: 5, name: 'Electric Bill', amount: 120.50, date: '2024-01-12', category: 'Utilities', description: 'Monthly electricity bill' },
  ]

  const getCategoryColor = (category) => {
    const colors = {
      'Food': 'category-food',
      'Transportation': 'category-transportation',
      'Entertainment': 'category-entertainment',
      'Utilities': 'category-utilities',
    }
    return colors[category] || 'category-default'
  }

  return (
    <div className="expenses-page">
      {/* Page Header */}
      <div className="page-header">
        <div className="page-title-section">
          <h1 className="page-title">Expenses</h1>
          <p className="page-subtitle">Manage and track your expenses</p>
        </div>
        <button className="add-expense-button">
          Add Expense
        </button>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="filter-group">
          <label className="filter-label">Search</label>
          <input
            type="text"
            placeholder="Search expenses..."
            className="filter-input"
          />
        </div>
        <div className="filter-group">
          <label className="filter-label">Category</label>
          <select className="filter-select">
            <option>All Categories</option>
            <option>Food</option>
            <option>Transportation</option>
            <option>Entertainment</option>
            <option>Utilities</option>
          </select>
        </div>
        <div className="filter-group">
          <label className="filter-label">Date Range</label>
          <select className="filter-select">
            <option>This Month</option>
            <option>Last Month</option>
            <option>This Year</option>
            <option>Custom</option>
          </select>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="expenses-table-container">
        <div className="table-header">
          <h2 className="table-title">All Expenses</h2>
        </div>
        <div className="table-wrapper">
          <table className="expenses-table">
            <thead>
              <tr>
                <th>Description</th>
                <th>Category</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((expense) => (
                <tr key={expense.id}>
                  <td>
                    <div className="expense-description">
                      <div className="expense-name">{expense.name}</div>
                      <div className="expense-desc">{expense.description}</div>
                    </div>
                  </td>
                  <td>
                    <span className={`category-badge ${getCategoryColor(expense.category)}`}>
                      {expense.category}
                    </span>
                  </td>
                  <td className="expense-amount">${expense.amount.toFixed(2)}</td>
                  <td className="expense-date">
                    {new Date(expense.date).toLocaleDateString()}
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button className="edit-button">Edit</button>
                      <button className="delete-button">Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Expenses